﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace FTC_MT
{
    public class MaquinaTuring
    {
        // 7-tupla
        private HashSet<string> Q;
        private HashSet<char> Sigma;
        private HashSet<char> Gamma;
        private Dictionary<(string estado, char le), (string novoEstado, char escreve, char direcao)> Delta;
        private string EstadoInicial;
        private string EstadoAceitacao;
        private string EstadoRejeicao;

        // Estado da simulação
        private Dictionary<int, char> fita;
        private int cabecote;
        private string estadoAtual;
        private int passos;
        private int limitePassos;

        public MaquinaTuring()
        {
            Q = new HashSet<string>();
            Sigma = new HashSet<char>();
            Gamma = new HashSet<char>();
            Delta = new Dictionary<(string, char), (string, char, char)>();
            EstadoInicial = "";
            EstadoAceitacao = "qaccept";
            EstadoRejeicao = "qreject";
            fita = new Dictionary<int, char>();
            cabecote = 0;
            limitePassos = 500;
        }

        public void Configurar(HashSet<string> estados, HashSet<char> alfabetoEntrada, HashSet<char> alfabetoFita,
                               string inicial, Dictionary<(string, char), (string, char, char)> delta)
        {
            Q = estados;
            Sigma = alfabetoEntrada;
            Gamma = alfabetoFita;
            EstadoInicial = inicial;
            Delta = delta;
        }

        public void DefinirLimite(int limite) => limitePassos = limite;

        private void InicializarFita(string entrada)
        {
            fita.Clear();
            cabecote = 0;
            for (int i = 0; i < entrada.Length; i++)
                fita[i] = entrada[i];
        }

        private char LerSimbolo() => fita.GetValueOrDefault(cabecote, '_');

        private void EscreverSimbolo(char simbolo)
        {
            if (simbolo == '_')
                fita.Remove(cabecote);
            else
                fita[cabecote] = simbolo;
        }

        private void MoverCabecote(char direcao)
        {
            if (direcao == 'R') cabecote++;
            else if (direcao == 'L') cabecote--;
        }

        private void ExibirConfiguracao()
        {
            Console.WriteLine($"Passo {passos} | Estado: {estadoAtual} | Posição: {cabecote}");
            if (fita.Count == 0)
            {
                Console.WriteLine("Fita: [_]");
                return;
            }
            int min = fita.Keys.Min();
            int max = fita.Keys.Max();
            for (int i = min; i <= max; i++)
            {
                char c = fita.GetValueOrDefault(i, '_');
                if (i == cabecote)
                    Console.Write($"[{c}]");
                else
                    Console.Write($" {c} ");
            }
            Console.WriteLine("\n----------------------------------------");
        }

        public string Executar(string entrada)
        {
            InicializarFita(entrada);
            estadoAtual = EstadoInicial;
            passos = 0;

            Console.WriteLine($"\n=== INICIANDO MT para: \"{entrada}\" ===");
            while (passos < limitePassos)
            {
                ExibirConfiguracao();

                if (estadoAtual == EstadoAceitacao)
                {
                    Console.WriteLine(">>> ACEITA (qaccept) <<<\n");
                    return "ACEITA";
                }
                if (estadoAtual == EstadoRejeicao)
                {
                    Console.WriteLine(">>> REJEITA (qreject) <<<\n");
                    return "REJEITA";
                }

                char simbolo = LerSimbolo();
                if (!Delta.ContainsKey((estadoAtual, simbolo)))
                {
                    Console.WriteLine($">>> REJEITA: transição indefinida para ({estadoAtual}, '{simbolo}') <<<\n");
                    return "REJEITA";
                }

                var (novoEstado, escreve, dir) = Delta[(estadoAtual, simbolo)];
                Console.WriteLine($"Aplicando: δ({estadoAtual}, '{simbolo}') = ({novoEstado}, '{escreve}', {dir})");

                EscreverSimbolo(escreve);
                estadoAtual = novoEstado;
                MoverCabecote(dir);
                passos++;
            }
            Console.WriteLine($">>> REJEITA: limite de passos ({limitePassos}) excedido <<<\n");
            return "REJEITA";
        }

        // ========== FÁBRICAS DAS MTs EXIGIDAS ==========

        // MT para L4 = { aⁿbⁿcⁿ | n>=1 }
        public static MaquinaTuring CriarMT_AnBnCn()
        {
            var mt = new MaquinaTuring();
            var estados = new HashSet<string> { "q0", "q1", "q2", "q3", "q4", "qaccept", "qreject" };
            var alfabetoEntrada = new HashSet<char> { 'a', 'b', 'c' };
            var alfabetoFita = new HashSet<char> { 'a', 'b', 'c', 'X', 'Y', 'Z', '_' };
            var delta = new Dictionary<(string, char), (string, char, char)>();

            // Marca um 'a' como X e vai para q1
            delta[("q0", 'a')] = ("q1", 'X', 'R');
            // Procura o primeiro 'b' não marcado
            delta[("q1", 'a')] = ("q1", 'a', 'R');
            delta[("q1", 'Y')] = ("q1", 'Y', 'R');
            delta[("q1", 'b')] = ("q2", 'Y', 'R');
            // Procura o primeiro 'c' não marcado
            delta[("q2", 'b')] = ("q2", 'b', 'R');
            delta[("q2", 'Z')] = ("q2", 'Z', 'R');
            delta[("q2", 'c')] = ("q3", 'Z', 'L');
            // Volta para o início
            delta[("q3", 'a')] = ("q3", 'a', 'L');
            delta[("q3", 'b')] = ("q3", 'b', 'L');
            delta[("q3", 'Y')] = ("q3", 'Y', 'L');
            delta[("q3", 'Z')] = ("q3", 'Z', 'L');
            delta[("q3", 'X')] = ("q0", 'X', 'R');
            // Verificação final
            delta[("q0", 'Y')] = ("q4", 'Y', 'R');
            delta[("q4", 'Y')] = ("q4", 'Y', 'R');
            delta[("q4", 'Z')] = ("q4", 'Z', 'R');
            delta[("q4", '_')] = ("qaccept", '_', 'R');
            // Rejeição para erros
            delta[("q0", 'b')] = ("qreject", 'b', 'R');
            delta[("q0", 'c')] = ("qreject", 'c', 'R');
            delta[("q1", 'c')] = ("qreject", 'c', 'R');
            delta[("q2", 'a')] = ("qreject", 'a', 'R');

            mt.Configurar(estados, alfabetoEntrada, alfabetoFita, "q0", delta);
            mt.DefinirLimite(500);
            return mt;
        }

        // MT que calcula f(n) = n+1 em unário (entrada: 1^n, saída: 1^(n+1))
        public static MaquinaTuring CriarMT_SucessorUnario()
        {
            var mt = new MaquinaTuring();
            var estados = new HashSet<string> { "q0", "q1", "q2", "qaccept", "qreject" };
            var alfabetoEntrada = new HashSet<char> { '1' };
            var alfabetoFita = new HashSet<char> { '1', '_' };
            var delta = new Dictionary<(string, char), (string, char, char)>();

            // Vai até o fim da fita, escreve um '1' e para
            delta[("q0", '1')] = ("q0", '1', 'R');
            delta[("q0", '_')] = ("q1", '1', 'L');  // escreve um 1 no primeiro branco
            delta[("q1", '1')] = ("q1", '1', 'L');
            delta[("q1", '_')] = ("qaccept", '_', 'R'); // volta para o início (opcional)

            mt.Configurar(estados, alfabetoEntrada, alfabetoFita, "q0", delta);
            mt.DefinirLimite(100);
            return mt;
        }

        // Processa arquivo de testes (uma cadeia por linha)
        public void ProcessarArquivo(string caminho)
        {
            if (!File.Exists(caminho))
            {
                Console.WriteLine($"Arquivo {caminho} não encontrado. Criando com casos padrão...");
                CriarArquivoTestes(caminho);
            }

            var linhas = File.ReadAllLines(caminho);
            foreach (var linha in linhas)
            {
                string cadeia = linha.Trim();
                if (cadeia == "") cadeia = "ε";
                string resultado = Executar(cadeia);
                Console.WriteLine($"\n>>> RESULTADO FINAL: {resultado}\n");
                Console.WriteLine("########################################\n");
            }
        }

        private void CriarArquivoTestes(string caminho)
        {
            // Para L4
            var casos = new[] { "abc", "aabbcc", "aaabbbccc", "aabbc", "ab", "abcabc", "" };
            File.WriteAllLines(caminho, casos);
            Console.WriteLine($"Arquivo {caminho} criado com {casos.Length} casos de teste.");
        }
    }
}